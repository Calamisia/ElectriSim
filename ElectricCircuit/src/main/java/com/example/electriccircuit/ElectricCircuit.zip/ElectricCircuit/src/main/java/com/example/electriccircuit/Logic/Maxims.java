package com.example.electriccircuit.Logic;

interface Maxims {

    public final double ELECTRONCHARGE = 1.6E-19;
    public final double COULOUMBCONSTANT = 8.99E9;
    public final double ELECTRICCONSTANT = 8.85E-12;

}