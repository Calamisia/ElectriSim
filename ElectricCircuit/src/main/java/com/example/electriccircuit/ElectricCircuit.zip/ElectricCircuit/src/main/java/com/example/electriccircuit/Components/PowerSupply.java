package com.example.electriccircuit.Components;

public class PowerSupply {
}
