package com.example.electriccircuit.Logic;

public class Budget {
}
